package com.example.c101212151lucasribeirodelacerda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C101212151LucasRibeiroDeLacerdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
