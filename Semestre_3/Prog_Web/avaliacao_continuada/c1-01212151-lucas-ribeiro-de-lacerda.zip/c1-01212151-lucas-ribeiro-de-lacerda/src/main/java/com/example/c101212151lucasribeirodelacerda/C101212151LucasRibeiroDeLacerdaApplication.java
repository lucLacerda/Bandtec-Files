package com.example.c101212151lucasribeirodelacerda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C101212151LucasRibeiroDeLacerdaApplication {

	public static void main(String[] args) {
		SpringApplication.run(C101212151LucasRibeiroDeLacerdaApplication.class, args);
	}

}
