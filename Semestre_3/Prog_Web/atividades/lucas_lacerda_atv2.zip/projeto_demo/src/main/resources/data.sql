insert into fabricante_veiculos_entity (nome) values
('Fabricante1'),
('Fabricante2');

insert into carro_entity (modelo, fabricante_id_fabricante, ano_fabricacao, potencia_motor)
values
('Modelo1', 1, 2020, 1.6),
('Modelo2', 2, 2012, 1.0),
('Modelo3', 1, 2012, 1.0),
('Modelo4', 2, 2012, 1.4);
