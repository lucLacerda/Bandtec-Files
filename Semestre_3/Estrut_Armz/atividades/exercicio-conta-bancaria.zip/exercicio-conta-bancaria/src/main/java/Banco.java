public class Banco {

  // Atributos
  PilhaObj<Operacao> pilhaOperacao = new PilhaObj(10);
  FilaObj<Operacao> filaOperacao = new FilaObj(10);
  // Contador de operações empilhadas
  Integer contadorOperacao = 0;

  // Métodos

  /*
   * Método debitar - recebe o valor a ser debitado e o objeto conta bancária
   * Se o débito ocorreu com sucesso, cria um objeto Operacao com os valores
   * adequados
   * e empilha a operação para poder ser desfeita. Atualiza contadorOperacao.
   */
  public void debitar(Double valor, ContaBancaria conta) {
    conta.debitar(valor);
    pilhaOperacao.push(new Operacao(conta, "Débito", valor));
    contadorOperacao++;
  }

  /*
   * Método depositar - recebe o valor a ser debitado e o objeto conta bancária
   * Executa o depósito, cria um objeto Operacao com os valores adequados
   * e empilha a operação para poder ser desfeita. Atualiza contadorOperacao.
   */
  public void depositar(Double valor, ContaBancaria conta) {
    conta.depositar(valor);
    pilhaOperacao.push(new Operacao(conta, "Depósito", valor));
    contadorOperacao++;
  }

  /*
   * Método desfazerOperacao - recebe a quantidade de operações a serem desfeitas
   * Se essa quantidade for inválida, lança IllegalArgumentException
   * Senão, "desfaz" a quantidade de operações passadas como argumento
   * e atualiza o contadorOperacao
   */
  public void desfazerOperacao(Integer qtdOperacaoDesfeita) {
    if (contadorOperacao < qtdOperacaoDesfeita || qtdOperacaoDesfeita == 0) {
      throw new IllegalArgumentException();
    }
    for (int i = 0; i < qtdOperacaoDesfeita; i++) {
      Operacao op = pilhaOperacao.pop();
      if (op.getTipoOperacao() == "Débito") {
        op.getContaBancaria().depositar(op.getValor());
      } else {
        op.getContaBancaria().debitar(op.getValor());
      }
      contadorOperacao--;
    }
  }

  /*
   * Método agendarOperacao - recebe o tipo da operaçõa, o valor e o objeto conta
   * bancária
   * Se um dos argumentos for inválido, lança IllegalArgumentException.
   * Senão, cria um objeto Operacao e insere esse objeto na fila.
   */
  public void agendarOperacao(String tipoOperacao, Double valor, ContaBancaria conta) {
    if (conta == null) {
      throw new IllegalArgumentException();
    }
    if (valor == null || valor <= 0) {
      throw new IllegalArgumentException();
    }

    if (tipoOperacao != "Débito" && tipoOperacao != "Depósito") {
      throw new IllegalArgumentException();
    }
    filaOperacao.insert(new Operacao(conta, tipoOperacao, valor));
  }

  /*
   * Método executarOperacoesAgendadas
   * Se não houver operações na fila, exibe mensagem de que não há operações
   * agendadas.
   * Senão, esvazia a fila, executando cada uma das operações agendadas.
   */
  public void executarOperacoesAgendadas() {
    System.out.println(filaOperacao.getFila());
    if (filaOperacao.isEmpty()) {
      System.out.println("Não há operações agendadas");
    }
    while (!filaOperacao.isEmpty()) {
      Operacao op = filaOperacao.poll();
      pilhaOperacao.push(op);
      contadorOperacao++;
    }
  }

  // Gettens
  public PilhaObj<Operacao> getPilhaOperacao() {
    return pilhaOperacao;
  }

  public FilaObj<Operacao> getFilaOperacao() {
    return filaOperacao;
  }

  public Integer getContadorOperacao() {
    return contadorOperacao;
  }
}
