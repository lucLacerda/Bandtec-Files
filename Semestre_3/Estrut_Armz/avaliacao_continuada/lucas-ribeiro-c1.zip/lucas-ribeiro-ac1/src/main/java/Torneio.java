public interface Torneio {

    public Integer getPremio();
}
