import java.util.Scanner;

public class App {
    public static void main(String[] args) {

        Scanner intScanner = new Scanner(System.in);

        ContaBancaria conta01 = new ContaBancaria(13579, 200.50);
        ContaBancaria conta02 = new ContaBancaria(24680, 3960.22);
        Banco banco = new Banco();
        Integer opcaoDigitada = 0;

        System.out.println("=================================================");
        System.out.println("======= Bem vindo ao app da SP Tech Bank! =======");
        System.out.println("=================================================");
        System.out.println("Escolha o que deseja fazer:");
        System.out.println("1- Debitar valor");
        System.out.println("2- Depositar valor");
        System.out.println("3- Desfazer operação");
        System.out.println("4- Agendar operação");
        System.out.println("5- Executar operações agendadas");
        System.out.println("6- Sair");
        System.out.println("=================================================");

        while (opcaoDigitada != 6){
            switch (opcaoDigitada){
                case 1:
                    int numConta = 0;
                    while (numConta != conta01.getNumero() || numConta != conta02.getNumero()) {
                        System.out.println("Digite o número da sua conta:");
                        numConta = intScanner.nextInt();
                        if(numConta != conta01.getNumero() || numConta != conta02.getNumero()){
                            System.out.println(">>> Conta inválida.");
                        }
                    }
                    System.out.println(">>> Conta válida.");
                    Double valorDebito = intScanner.nextDouble();
                    try{
                        if(numConta == conta01.getNumero()){
                            banco.debitar(valorDebito, conta01);
                        }
                        if(numConta == conta02.getNumero()){
                            banco.debitar(valorDebito, conta02);
                        }
                    }
                    catch (IllegalStateException error){
                        error.getMessage();
                    }
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    System.out.println("Saindo...");
                    break;
            }
        }
    }
}
