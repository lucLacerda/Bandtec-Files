public class FilaObj<T> {

    // Atributos
    private int tamanho;
    private T[] fila;

    // Construtor
    public FilaObj(int capacidade) {
        tamanho = 0;
        fila = (T[]) new Object[capacidade];
    }

    // Métodos

    // Retorna true se a fila está vazia e false coso contrário
    public boolean isEmpty() {
        if(tamanho == 0){
            return true;
        }
        return false;
    }

    // Retorna true se a fila está cheia e false caso contrário
    public boolean isFull() {
        if(tamanho == fila.length){
            return true;
        }
        return false;
    }

    // Se a fila não estiver cheia, insere info na fila
    // Se a fila estiver cheia, deve lançar IllegalStateException
    public void insert(T info) {
        if(isFull()){
            throw new IllegalStateException();
        }
        fila[tamanho] = info;
        tamanho ++;
    }

    // Retorna o primeiro da fila
    public T peek() {
        if(isEmpty()){
            return null;
        }
        return fila[0];
    }

    // Remove e retorna o primerio elemento da fila
    // Antes de retorna, se a fila não estiver vazia, deve fazer a fila "andar"
    public T poll() {
        if(isEmpty()){
            return null;
        }
        T aux = fila[0];
        int tamanhoAtual = tamanho;
        for (int i = 1; i <= tamanhoAtual; i++) {
            if (fila[i - 1] == null) {
                break;
            }
            fila[i - 1] = fila[i];
        }
        tamanho--;
        fila[tamanhoAtual] = null;
        return aux;
    }

    // Exibe os elementos da fila
    public void exibe() {
        for (int i = 0; i < tamanho; i++) {
            System.out.println(fila[i]);
        }
    }

    // Retorna o vetor fila

    public int getTamanho() {
        return tamanho;
    }

    public T[] getFila() {
        return fila;
    }
}