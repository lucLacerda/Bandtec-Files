package sptech;

public class Pilha {

    // 01) Atributos
    private int[] pilha;
    private int topo = -1;

    // 02) Construtor
    public Pilha(int capacidade) {
        pilha = new int[capacidade];
    }

    // 03) Método isEmpty
    public Boolean isEmpty() {
        if(topo == -1){
            return true;
        }
        else{
            return false;
        }
    }
    // 04) Método isFull
    public Boolean isFull() {
        if(topo == pilha.length -1){
            return true;
        }
        else{
            return false;
        }
    }

    // 05) Método push
    public void push(int info) {
        if(isFull()){
            System.out.println("Pilha cheia");
            throw new IllegalStateException();
        }
        else{
            pilha[topo + 1] = info;
            topo++;
        }

    }

    // 06) Método pop
    public int pop() {
        int aux = pilha[topo];
        pilha[topo] = 0;
        topo --;
        return aux;
    }

    // 07) Método peek
    public int peek() {
        if(isEmpty()){
            return-1;
        }
        else{
            return pilha[topo];
        }
    }

    // 08) Método exibe
    public void exibe() {
        for(int i = 0; i < topo; i++){
            System.out.println(pilha[i]);
        }
    }


    //Getters & Setters (manter)
    public int getTopo() {
        return topo;
    }
}