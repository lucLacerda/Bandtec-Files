package sptech;

public class Teste {
}
