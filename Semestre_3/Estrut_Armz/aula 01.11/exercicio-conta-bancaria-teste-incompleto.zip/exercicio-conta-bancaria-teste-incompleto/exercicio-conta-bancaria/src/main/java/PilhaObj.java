public class PilhaObj<T> {

    // Atributos
    private T[] pilha;
    private int topo;

    // Construtor
    public PilhaObj(int capacidade) {

    }

    // Métodos

    // Retorna true se a pilha estiver vazia e false caso contrário
    public Boolean isEmpty() {
        return false;
    }

    // Retorna true se a pilha estiver cheia e false caso contrário
    public Boolean isFull() {
        return false;
    }

    // Se a pilha estiver cheia, deve lançar IllegalStateException
    // Se a pilha não estiver cheia, empilha info
    public void push(T info) {

    }

    // Desempilha e retorna o elemento do topo da pilha
    public T pop() {
        return null;
    }

    // Retorna o elemento do topo da pilha, sem desempilhar
    public T peek() {
        return null;
    }

    // Exibe o conteúdo da pilha
    public void exibe() {

    }

}