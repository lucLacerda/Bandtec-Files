package sptech;

public class Teste {
    public static Boolean isPalindromo(int[] v ){
        Pilha pilha = new Pilha(v.length);

        for (int i = 0; i < v.length; i++){
            pilha.push(v[i]);
        }

        for (int i = 0; i < v.length; i++){
            if (v[i] != pilha.pop()){
                return false;
            }
        }

        return true;
    }

    public static int getLog(int num){
        return (int)(Math.log(num)/Math.log(2)) + 1;
    }

    public static String decimalParaBinario(int numero){
        Pilha pilha = new Pilha (getLog(numero));
        String binario = "";

        while(numero !=0){
            pilha.push((int)numero%2);
            numero = numero/2;
        }

        while(!pilha.isEmpty()){
            binario += String.valueOf(pilha.pop());
        }
        return binario;
    }

    public static void main(String[] args) {
        int[] vetor1 = {1,3,3,1};
        int[] vetor2 = {10,20,30,40};
        int[] vetor3 = {1,2,3,2,1};

        System.out.println("vetor1 é palindromo?" + isPalindromo(vetor1));
        System.out.println("vetor2 é palindromo?" + isPalindromo(vetor2));
        System.out.println("vetor3 é palindromo?" + isPalindromo(vetor3));

        System.out.println("7 em binário: " + decimalParaBinario(49));
    }
}
