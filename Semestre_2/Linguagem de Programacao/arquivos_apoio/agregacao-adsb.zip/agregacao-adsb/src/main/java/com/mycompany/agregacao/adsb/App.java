/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.agregacao.adsb;

/**
 *
 * @author isaque.santos@VALEMOBI.CORP
 */
public class App {

    public static void main(String[] args) {
        Contato c1 = new Contato("Jil","209138",false);
        Contato c2 = new Contato("Appa","0923489483",false);
        
        Grupo g1 = new Grupo("Teste grupo");
        
        g1.adiciona(c2);
        g1.adiciona(c1);
        System.out.println(g1.getContatos());
        
    }
}
